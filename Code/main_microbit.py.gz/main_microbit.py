from microbit import *
import math
import random

L = -1
R = 1


def light_test():
    # Light up all the LEDs on the Micro:bit display
    for x in range(5):
        for y in range(5):
            display.set_pixel(x, y, 9)

    # Pause for a moment to keep the LEDs lit
    sleep(1000)

    for x in range(5):
        for y in range(5):
            display.set_pixel(x, y, 0)

    sleep(1000)


light_test()


def random_choice(l_prob, r_prob):
    if round(l_prob + r_prob, 3) != 1.0:
        raise ValueError("The probabilities must sum to 1.")
    random_number = random.random()
    if random_number < l_prob:
        return L
    return R


class BushMostellerBot:
    def __init__(
        self,
        numberOfGameTurns=20,
        l_prob=0.5,
        r_prob=0.5,
        aspiration_level_divider=2.0,
        learning_rate=0.5,
    ):
        self._l_prob, self._r_prob = l_prob, r_prob
        self._init_l_prob, self._init_r_prob = l_prob, r_prob
        self._aspiration_level = abs(1 / aspiration_level_divider)
        self._stimulus = 0.0
        self._learning_rate = learning_rate
        self.numberOfGameTurns = numberOfGameTurns

    def updateUserMove(self, opponent_move):
        my_payoff = 1 if self.prev_move == opponent_move else 0
        self._stimulus = (my_payoff - self._aspiration_level) / abs(
            1 - self._aspiration_level
        )
        if self._stimulus < -1:
            self._stimulus = -1

    def updateBotPrediction(self):
        if self.prev_move == L:
            if self._stimulus >= 0:
                self._l_prob += (
                    self._learning_rate * self._stimulus * (1 - self._l_prob)
                )
            elif self._stimulus < 0:
                self._l_prob += self._learning_rate * self._stimulus * self._l_prob
            self._r_prob = 1 - self._l_prob
        elif self.prev_move == R:
            if self._stimulus >= 0:
                self._r_prob += (
                    self._learning_rate * self._stimulus * (1 - self._r_prob)
                )
            elif self._stimulus < 0:
                self._r_prob += self._learning_rate * self._stimulus * self._r_prob
            self._l_prob = 1 - self._r_prob

    def getBotPrediction(self):
        self.prev_move = random_choice(self._l_prob, self._r_prob)
        return self.prev_move


USERWIN = -1
BOTWIN = 1
REGULAR_DATA_SERIES = 1
FLIPPING_DATA_SERIES = 2
USER_REACTIVE = 3
BOT_REACTIVE = 4
USER_REACTIVE_REG_DATA = 5


class BaselineBot:
    def __init__(self, numberOfGameTurns):
        self.resetBot(numberOfGameTurns)

    def resetBot(self, numberOfGameTurns):
        self.numberOfGameTurns = numberOfGameTurns
        self.userMoves = []
        self.userMovesFlipping = []
        self.botMoves = []
        self.wins = []
        self.gameTurn = 0
        self.initPredictors()
        self.updateBotPrediction()

    def updateUserMove(self, userMove):
        self.userMoves.append(userMove)
        if len(self.userMoves) > 1:
            if self.userMoves[self.gameTurn] == self.userMoves[self.gameTurn - 1]:
                self.userMovesFlipping.append(-1)
            else:
                self.userMovesFlipping.append(1)
        self.wins.append(BOTWIN if userMove == self.getBotPrediction() else USERWIN)
        self.gameTurn += 1
        self.updateBotPrediction()

    def getBotPrediction(self):
        return self.botMoves[self.gameTurn]

    def updateBotPrediction(self):
        botPredictionProb = self.aggregateExperts()
        sample = random.random() * 2 - 1
        if botPredictionProb < sample:
            botPrediction = -1
        else:
            botPrediction = 1
        if len(self.botMoves) <= self.gameTurn:
            self.botMoves.append(botPrediction)
        else:
            self.botMoves[self.gameTurn] = botPrediction

    def aggregateExperts(self):
        eta = math.sqrt(
            math.log(len(self.predictors)) / (2 * self.numberOfGameTurns - 1)
        )
        denominator = 0
        numerator = 0
        for expertInd in range(len(self.predictors)):
            expertPastAccuracy = self.predictors[expertInd].getPastAccuracy(
                self.userMoves
            )
            expertWeight = math.exp(-1 * eta * expertPastAccuracy)
            currentPrediction = self.predictors[expertInd].makePrediction(
                self.userMoves, self.userMovesFlipping, self.wins
            )
            numerator += currentPrediction * expertWeight
            denominator += expertWeight
        q = numerator / denominator
        return q

    def randomPredictor(self):
        return random.randint(-1, 1)

    def initPredictors(self):
        self.predictors = []
        biasPredictorMemory = [2, 3, 5]
        for bp in range(len(biasPredictorMemory)):
            self.predictors.append(
                BiasPredictor(biasPredictorMemory[bp], REGULAR_DATA_SERIES)
            )
        biasPredictorMemory = [2, 3, 5]
        for bp in range(len(biasPredictorMemory)):
            self.predictors.append(
                BiasPredictor(biasPredictorMemory[bp], FLIPPING_DATA_SERIES)
            )
        patternPredictorMemory = [2, 3, 4, 5]
        for bp in range(len(patternPredictorMemory)):
            self.predictors.append(
                PatternPredictor(patternPredictorMemory[bp], REGULAR_DATA_SERIES)
            )
        patternPredictorMemory = [2, 3, 4, 5]
        for bp in range(len(patternPredictorMemory)):
            self.predictors.append(
                PatternPredictor(patternPredictorMemory[bp], FLIPPING_DATA_SERIES)
            )
        reactivePredictorMemory = [1, 2]
        for bp in range(len(reactivePredictorMemory)):
            self.predictors.append(
                ReactivePredictor(reactivePredictorMemory[bp], USER_REACTIVE)
            )
        reactivePredictorMemory = [1, 2]
        for bp in range(len(reactivePredictorMemory)):
            self.predictors.append(
                ReactivePredictor(reactivePredictorMemory[bp], USER_REACTIVE_REG_DATA)
            )


class Predictor:
    def __init__(self, memoryLength, dataType):
        self.memoryLength = memoryLength
        self.dataType = dataType
        self.predictionsHistory = []

    def getPastAccuracy(self, userMoves):
        pastAccuracy = 0
        for i in range(len(userMoves)):
            pastAccuracy += abs(userMoves[i] - self.predictionsHistory[i])
        return pastAccuracy

    def makePrediction(self, userMoves, userMovesFlipping, wins):
        prediction = 0
        if self.dataType == REGULAR_DATA_SERIES:
            prediction = self.childPredictor(userMoves)
        elif self.dataType == FLIPPING_DATA_SERIES:
            prediction = (
                self.childPredictor(userMovesFlipping) * userMoves[-1] * -1
                if userMoves
                else 0
            )
        elif self.dataType == USER_REACTIVE:
            prediction = (
                self.childPredictor(userMovesFlipping, wins) * userMoves[-1] * -1
                if userMoves
                else 0
            )
        elif self.dataType == USER_REACTIVE_REG_DATA:
            prediction = self.childPredictor(userMoves, wins)
        if not prediction or math.isnan(prediction):
            prediction = 0
        self.predictionsHistory.append(prediction)
        return prediction


class BiasPredictor(Predictor):
    def __init__(self, memoryLength, dataType):
        super().__init__(memoryLength, dataType)

    def childPredictor(self, data):
        historyMean = 0
        cnt = 0
        while cnt < self.memoryLength and len(data) - cnt > 0:
            historyMean += data[len(data) - cnt - 1]
            cnt += 1
        try:
            historyMean /= cnt
        except:
            return 0
        return historyMean


class PatternPredictor(Predictor):
    def __init__(self, memoryLength, dataType):
        super().__init__(memoryLength, dataType)

    def childPredictor(self, data):
        pattern = []
        prediction = 0
        score = 0
        ind = 0
        if len(data) < self.memoryLength:
            return 0

        def rotatePattern():
            temp = pattern.pop()
            pattern.insert(0, temp)

        pattern = data[: -self.memoryLength]
        if len(pattern) == 0:
            return 0
        prediction = pattern[0]
        ind = len(data) - self.memoryLength - 1
        while ind >= max(0, len(data) - 3 * self.memoryLength):
            if pattern[len(pattern) - 1] == data[ind]:
                score += 1
            rotatePattern()
            ind -= 1
        score /= 2 * self.memoryLength
        return prediction * score


class ReactivePredictor(Predictor):
    def __init__(self, memoryLength, dataType):
        super().__init__(memoryLength, dataType)
        self.stateMachine = [0] * 2 ** (2 * memoryLength - 1)
        self.indMap = []
        for i in range(2 * memoryLength, -1, -1):
            self.indMap.append(2**i)

    def childPredictor(self, moves, wins):
        if len(moves) == 0:
            return 0
        lastMoves = (
            moves[-self.memoryLength :] if len(moves) >= self.memoryLength else moves
        )
        lastWins = (
            wins[-self.memoryLength :] if len(wins) >= self.memoryLength else wins
        )
        lastState = lastWins + lastMoves
        lastStateInd = 0
        for i in range(len(lastState)):
            if lastState[i] == 1:
                lastStateInd += 2**i
        if lastStateInd >= len(self.stateMachine):
            lastStateInd = len(self.stateMachine) - 1
        lastStateResult = lastMoves[-1] if lastMoves else 0
        if self.stateMachine[lastStateInd] == 0:
            self.stateMachine[lastStateInd] = lastStateResult * 0.3
        elif self.stateMachine[lastStateInd] == lastStateResult * 0.3:
            self.stateMachine[lastStateInd] = lastStateResult * 0.8
        elif self.stateMachine[lastStateInd] == lastStateResult * 0.8:
            self.stateMachine[lastStateInd] = lastStateResult * 1
        elif self.stateMachine[lastStateInd] == lastStateResult * 1:
            self.stateMachine[lastStateInd] = lastStateResult * 1
        else:
            self.stateMachine[lastStateInd] = 0
        currentMoves = (
            moves[-self.memoryLength + 1 :]
            if len(moves) >= self.memoryLength
            else moves
        )
        currentWins = (
            wins[-self.memoryLength :] if len(wins) >= self.memoryLength else wins
        )
        currentState = currentWins + currentMoves
        currentStateInd = 0
        for i in range(len(currentState)):
            if currentState[i] == 1:
                currentStateInd += 2**i
        if currentStateInd >= len(self.stateMachine):
            currentStateInd = len(self.stateMachine) - 1
        predictionAndScore = self.stateMachine[currentStateInd]
        return predictionAndScore if predictionAndScore else 0


NUM_GAME_TURNS = 20
numberOfGameTurns = NUM_GAME_TURNS
maxTime = 10
timePerTurn = 3
userScore = 0
machineScore = 0
turnNumber = 0
timeLeft = maxTime
currentTurnTime = timePerTurn
gameStarted = False00333
Bot = BaselineBot
bot = Bot(numberOfGameTurns)


def userAction(key):
    global timeLeft, currentTurnTime, machineScore, userScore, gameStarted
    gameStarted = True
    if currentTurnTime > 0:
        timeLeft += currentTurnTime
        if timeLeft > maxTime:
            timeLeft = maxTime
    currentTurnTime = timePerTurn
    if bot.getBotPrediction() == key:
        machineScore += 1
    else:
        userScore += 1
    scoreUpdate()
    bot.updateUserMove(key)
    bot.updateBotPrediction()


def button_a_pressed():
    print("A pressed")
    userAction(-1)


def button_b_pressed():
    print("B pressed")
    userAction(1)


def scoreUpdate():
    global userScore, machineScore, gameStarted
    if userScore >= numberOfGameTurns / 2:
        gameStarted = False
        display.scroll("User won!")
        print("User won!")
        return
    if machineScore >= numberOfGameTurns / 2:
        gameStarted = False
        display.scroll("Machine won!")
        print("Machine won!")
        return
    updateGraphics()


def restartGame():
    global numberOfGameTurns, userScore, machineScore, turnNumber, timeLeft, currentTurnTime, gameStarted, bot
    numberOfGameTurns = NUM_GAME_TURNS
    maxTime = 10  # Add the value of maxTime back
    timePerTurn = 3
    userScore = 0
    machineScore = 0
    turnNumber = 0
    timeLeft = maxTime
    currentTurnTime = timePerTurn
    gameStarted = False
    bot = Bot(numberOfGameTurns)


def updateGraphics():
    global userScore, machineScore, gameStarted, numberOfGameTurns, bot
    print("User: {0}  Machine: {1}".format(userScore, machineScore))
    display.clear()
    display.show("U:" + str(userScore) + "M:" + str(machineScore))


def update_timer():
    global userScore, machineScore, turnNumber, timeLeft, currentTurnTime, gameStarted, last_time_check

    current_time = running_time()
    elapsed_time = current_time - last_time_check

    if gameStarted and elapsed_time >= 1000:
        last_time_check = current_time
        timeLeft -= 1
        currentTurnTime -= 1

        if timeLeft == 0:
            machineScore += 1
            timeLeft = maxTime
            currentTurnTime = timePerTurn
            scoreUpdate()


# Initialize the last_time_check variable
last_time_check = running_time()

while True:
    if button_a.is_pressed():
        button_a_pressed()
    elif button_b.is_pressed():
        button_b_pressed()

    update_timer()
